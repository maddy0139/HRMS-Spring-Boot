package com.hrms.util;

public interface AppConstants {
    String DEFAULT_DESIGNATION_ID = "1";
    
}
