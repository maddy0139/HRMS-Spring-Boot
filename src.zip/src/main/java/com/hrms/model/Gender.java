package com.hrms.model;

public enum Gender {
MALE,
FEMALE,
OTHER
}
